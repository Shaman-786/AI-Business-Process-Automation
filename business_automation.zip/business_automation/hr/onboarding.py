from utils.email_util import send_email

def send_welcome_email(employee_email, name):
    subject = f"Welcome to the Company, {name}!"
    body = f"""
    Hi {name},

    Welcome to our team! We’re excited to have you onboard.

    Regards,  
    HR Team
    """
    send_email(to=employee_email, subject=subject, body=body)
