from utils.email_util import send_email

def email_leads():
    leads = [
        {"name": "Client A", "email": "clienta@example.com"},
        {"name": "Client B", "email": "clientb@example.com"},
    ]
    for lead in leads:
        subject = f"Special Offer for {lead['name']}"
        body = f"Dear {lead['name']},\n\nWe have an exclusive offer just for you!"
        send_email(to=lead['email'], subject=subject, body=body)
