from utils.email_util import send_email

def auto_reply_to_tickets():
    tickets = [
        {"email": "user1@example.com", "subject": "Issue with login"},
        {"email": "user2@example.com", "subject": "Need invoice copy"},
    ]
    for ticket in tickets:
        reply_subject = f"RE: {ticket['subject']}"
        reply_body = "Thanks for reaching out. Our support team will get back to you shortly."
        send_email(to=ticket['email'], subject=reply_subject, body=reply_body)
