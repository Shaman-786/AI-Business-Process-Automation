from hr.onboarding import send_welcome_email
from sales.lead_emailer import email_leads
from support.auto_reply import auto_reply_to_tickets

def run_hr_tasks():
    employees = [
        {"name": "Ayesha", "email": "ayesha@company.com"},
        {"name": "Ali", "email": "ali@company.com"},
    ]
    for emp in employees:
        send_welcome_email(emp['email'], emp['name'])

def run_sales_tasks():
    email_leads()

def run_support_tasks():
    auto_reply_to_tickets()

if __name__ == "__main__":
    run_hr_tasks()
    run_sales_tasks()
    run_support_tasks()
